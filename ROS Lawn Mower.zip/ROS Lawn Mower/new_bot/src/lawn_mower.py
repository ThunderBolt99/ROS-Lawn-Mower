#!/usr/bin/env python3
import go_to_point
import rospy
import time
import sys
import importlib

if len(sys.argv) > 1:
    #pos_x=float(sys.argv[1])
    #pos_y=float(sys.argv[2])
    l=int(sys.argv[1])
    b=int(sys.argv[2])
    laps=int(sys.argv[3])
else:
    print("%s [Invalid dimensions]" %sys.argv[0])
    sys.exit(1)

rospy.init_node('move_robot')

prec=0.25 # go to point precision
temp=0
pos_x=0
pos_y=0
for j in range(laps):


    for i in range(0,max(l,b)+2,2):

            go_to_point.main(prec+pos_x+l,pos_y+i,0)
            importlib.reload(go_to_point)
            if i>=b and b%2==0:
                break

            go_to_point.main(pos_x+l+0.1,pos_y+i+1+prec,0)
            importlib.reload(go_to_point)
            go_to_point.main(pos_x+l-0.3,pos_y+i+1,0)
            importlib.reload(go_to_point)
            if b%2==1 and i+1 >=b :
                break

            go_to_point.main(pos_x+temp,prec+pos_y+i+2,0)
            importlib.reload(go_to_point)

    go_to_point.main(pos_x-0.1,pos_y+b-prec,0)
    importlib.reload(go_to_point)
    go_to_point.main(pos_x-0.2,pos_y-0.2,0)
    importlib.reload(go_to_point)
